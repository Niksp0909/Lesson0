name = 'Сергей'
print(name)
age = 36
print(age)
age = 36+1
print(age)
is_student = True
print(is_student)
